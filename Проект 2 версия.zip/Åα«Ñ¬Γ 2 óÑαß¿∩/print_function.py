import pygame


def print_text(screen, message, x, y, end=0, font_color=(255, 255, 255), font_type='media/FiraSans-Italic.ttf', font_size=30):
    pygame.font.init()
    font_type = pygame.font.SysFont('segoeprint', font_size)
    text = font_type.render(message, True, font_color)
    if end > 1:
        words = []
        for i in message:
            words.append(i)
            if len(words) % end == 0:
                words.append('-')

        message = "".join(words)
        list_words = message.split('-')
        list_length = len(list_words)
        for i in range(0, list_length):
            j = i + 1
            y_i = y * j
            list_text = font_type.render(list_words[i], True, font_color)
            screen.blit(list_text, (x, y_i))
    else:
        screen.blit(text, (x, y))