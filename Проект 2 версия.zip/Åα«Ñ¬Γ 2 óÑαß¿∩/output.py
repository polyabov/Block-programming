with open('console.txt', 'w') as file:
	file.write('')
file = open('console.txt', 'a')
if asder:
print(sdfg, file=file)

file.close()