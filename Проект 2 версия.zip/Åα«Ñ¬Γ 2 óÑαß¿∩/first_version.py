def main():
    global WIDTH, HEIGHT

    running = True

    section = []
    len_button = buttons['pink'].get_width()
    for k in range(1, 10, 2):
        section.append(pygame.Rect((WIDTH // 18 - len_button // 2, HEIGHT * k // 14 - len_button // 2),
                                   (len_button * 2, len_button * 2)))
    pygame.font.get_fonts()
    font = pygame.font.SysFont('segoeprint', 30)
    font2 = pygame.font.SysFont('segoeprint', 20)
    text1 = 'Основные'
    text2 = '/'
    # flag = False
    motion = -1
    flag2 = -1
    while running:

        radius_circle = WIDTH // 50 + 20
        WIDTH = screen.get_width()
        HEIGHT = screen.get_height()

        screen.fill(WHITE)

        screen.blit(background, (0, 0))
        for k, j in zip(range(5), range(1, 10, 2)):
            section[k].topleft = (len_button // 2, HEIGHT * j // 10 - len_button // 2)
            section[k].size = (len_button, len_button)

        events = pygame.event.get()
        for i in events:
            if i.type == pygame.QUIT:
                running = False
            if section[0].collidepoint(pygame.mouse.get_pos()):
                flag2 = 1
                text2 = 'Основные'
            elif section[1].collidepoint(pygame.mouse.get_pos()):
                flag2 = 3
                text2 = 'Переменные'
            elif section[2].collidepoint(pygame.mouse.get_pos()):
                flag2 = 5
                text2 = 'Методы и функции'
            elif section[3].collidepoint(pygame.mouse.get_pos()):
                flag2 = 7
                text2 = 'Типы данных и математика'
            elif section[4].collidepoint(pygame.mouse.get_pos()):
                flag2 = 9
                text2 = 'Условные операторы и циклы'
            else:
                flag2 = -1
            if i.type == pygame.MOUSEBUTTONDOWN:
                if section[0].collidepoint(pygame.mouse.get_pos()):
                    text1 = 'Основные'
                    basic()
                elif section[1].collidepoint(pygame.mouse.get_pos()):
                    text1 = 'Переменные'
                    vars()
                elif section[2].collidepoint(pygame.mouse.get_pos()):
                    text1 = 'Методы и функции'
                    methods_and_functions()
                elif section[3].collidepoint(pygame.mouse.get_pos()):
                    text1 = 'Типы данных и математика'
                    vars_types_and_math()
                elif section[4].collidepoint(pygame.mouse.get_pos()):
                    text1 = 'Условные операторы и циклы'
                    conditions_and_loops()

            # if i.type == pygame.MOUSEBUTTONUP:
            #   flag = False
        text_print = font.render(text1, True, WHITE)
        text2_print = font2.render(text2, True, BLACK)
        if flag2 != -1:
            screen.blit(text2_print, (len_button // 2 - flag2 * 3, HEIGHT * flag2 // 10 - len_button // 2 + 80))

        screen.blit(text_print, (len_button * 2 + 10, len_button // 2))

        for i, color in zip(range(len(buttons.keys())), buttons.keys()):
            screen.blit(buttons[color], section[i].topleft)
        # pygame.draw.line(screen,BLACK, (section[0].centerx + len_button // 2, 0), (section[0].centerx + len_button // 2, HEIGHT), 3)
        pygame.display.update()
        clock.tick(FPS)