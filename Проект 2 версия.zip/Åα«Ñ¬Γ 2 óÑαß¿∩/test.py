def file_reader():
    with open('output.py', 'r') as file:
        executable_code = ''
        flag = False
        for line in file.readlines():
            if 'if' in line:
                executable_code += line + ' '
                flag = True
                continue
            elif '    ' in line:
                executable_code += line + '; '
                continue
            elif flag and '    ' not in line:
                flag = False
                executable_code += '\n'
            executable_code += line + '\n'
    print(executable_code)
    return executable_code


from contextlib import redirect_stdout
import io
io.
f = io.StringIO()
exec('print("Hi")')
with redirect_stdout(f):
    help(pow)
s = f.getvalue()
print(s)