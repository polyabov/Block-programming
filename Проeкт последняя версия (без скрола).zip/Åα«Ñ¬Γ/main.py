import pygame
import pygame_widgets
from pygame_widgets.textbox import TextBox
import basic_section1
import vars_section2
import math_section3
import methods_and_functions_section4
import conditions_and_loops_section5
#import sys


def draw_the_arrow(x0, y0, h):
    pygame.draw.polygon(screen, (0, 0, 0),
                        ((x0 - 3, y0), (x0 + 3, y0), (x0 + 3, y0 + h - 5), (x0 + 7, y0 + h - 5), (x0, y0 + h),
                         (x0 - 7, y0 + h - 5), (x0 - 3, y0 + h - 5)))


def menu():
    global WIDTH, HEIGHT, screen, clock, FPS, WHITE, BLACK, font, font_main_title, font2, back1, back2, back2_2

    text_title = font_main_title.render('МЕНЮ:', True, WHITE)
    text_continue = font.render('Продолжить', True, BLACK)
    text_exit = font.render('Выйти', True, BLACK)
    text_menu = font.render('Сменить фон', True, BLACK)

    running = True

    button_continue = pygame.Rect((WIDTH * 0.5 - run_delete_button_image.get_width() // 2, HEIGHT * 0.3),
                                  (WIDTH * 0.2 + 150, HEIGHT * 0.1))
    button_exit = pygame.Rect((WIDTH * 0.5 - run_delete_button_image.get_width() // 2, HEIGHT * 0.5),
                              (WIDTH * 0.2 + 150, HEIGHT * 0.1))
    button_menu = pygame.Rect \
        ((WIDTH * 0.5 - run_delete_button_image.get_width() // 2, HEIGHT * 0.7), (WIDTH * 0.2 + 150, HEIGHT * 0.1))
    while running:
        background = back2

        screen.blit(background, (0, 0))

        screen.blit(text_title, (WIDTH * 0.5 - 100, HEIGHT * 0.1))

        #pygame.draw.rect(screen, WHITE, button_continue)
        #pygame.draw.rect(screen, WHITE, button_exit)
        #pygame.draw.rect(screen, WHITE, button_menu)
        screen.blit(run_delete_button_image, button_continue)
        screen.blit(run_delete_button_image, button_exit)
        screen.blit(run_delete_button_image, button_menu)
        #screen.blit(text_continue, button_continue.topleft)
        #screen.blit(text_exit, button_exit.topleft)
        #screen.blit(text_menu, button_menu.topleft)
        screen.blit(text_continue, (button_continue.centerx - 180, button_continue.centery - 30))
        screen.blit(text_exit, (button_exit.centerx - 140, button_exit.centery - 30))
        screen.blit(text_menu, (button_menu.centerx - 190, button_menu.centery - 30))
        for i in pygame.event.get():
            if i.type == pygame.QUIT:
                running = False
            elif i.type == pygame.KEYDOWN and i.key == pygame.K_ESCAPE:
                return
            if button_continue.collidepoint(pygame.mouse.get_pos()):
                if i.type == pygame.MOUSEBUTTONDOWN:
                    return
            elif button_exit.collidepoint(pygame.mouse.get_pos()):
                if i.type == pygame.MOUSEBUTTONDOWN:
                    return False
            elif button_menu.collidepoint(pygame.mouse.get_pos()):
                if i.type == pygame.MOUSEBUTTONDOWN:
                    back1, back2, back2_2 = back2, back2_2, back1

        pygame.display.update()
        clock.tick(FPS)


def start_menu():
    global WIDTH, HEIGHT, screen, clock, FPS, WHITE, BLACK,  font_main_title, font2, back1

    text_title = font_main_title.render('БЛОЧНОЕ ПРОГРАММИРОВАНИЕ', True, WHITE)
    text_start = font.render('Начать', True, BLACK)
    text_esc = font2.render('Чтобы выйти нажмите Escape', True, BLACK)
    background = back1
    running = True
    while running:

        screen.blit(background, (0, 0))

        button_start = pygame.Rect\
            ((WIDTH * 0.5 - run_delete_button_image.get_width() // 2, HEIGHT * 0.4), (WIDTH * 0.2 + 150, HEIGHT * 0.1))

        screen.blit(text_title, (WIDTH * 0.2, HEIGHT * 0.2))

        #pygame.draw.rect(screen, WHITE, button_start)
        screen.blit(run_delete_button_image, button_start)
        screen.blit(text_start, (button_start.centerx - 150, button_start.centery - 30))
        screen.blit(text_esc, (button_start.centerx - 250, HEIGHT * 0.9))
        for i in pygame.event.get():
            if i.type == pygame.QUIT or (i.type == pygame.KEYDOWN and i.key == pygame.K_ESCAPE):
                running = False
            if button_start.collidepoint(pygame.mouse.get_pos()):
                if i.type == pygame.MOUSEBUTTONDOWN:
                    return main()

        pygame.display.update()
        clock.tick(FPS)


def input_text(helping_text_list):
    global WIDTH, HEIGHT, screen, clock, FPS, WHITE, BLACK, font, font2, back2

    #def output():
    #    global text
    #    text = textbox.getText()

    textbox = TextBox(screen, 1000, 100, 400, 60, fontSize=50, borderColour=(0, 0, 0), textColour=(0, 0, 200),
                      radius=10, borderThickness=4)

    running = True
    while running:
        screen.blit(back2, (0, 0))
        events = pygame.event.get()
        for i in events:
            if i.type == pygame.QUIT:
                return None
            elif i.type == pygame.KEYDOWN and i.key == pygame.K_RETURN and textbox.getText():
                pygame_widgets.update(events)
                return textbox.getText()
        y = 100
        for helping_text in helping_text_list:
            text_out = font.render(helping_text, True, BLACK)
            screen.blit(text_out, (100, y))
            y += 60
        pygame_widgets.update(events)

        pygame.display.update()
        clock.tick(FPS)

def main():
    global WIDTH, HEIGHT, screen, clock, FPS, WHITE, BLACK, font, font2, text
    program = []
    module = None
    names_rects = None

    running = True
    run_button = None
    delete_button = None
    n_button = None

    len_button = buttons['pink'].get_width()
    for k in range(1, 10, 2):
        section.append(pygame.Rect((WIDTH // 18 - len_button // 2, HEIGHT * k // 14 - len_button // 2),
                                   (len_button * 2, len_button * 2)))



    text1 = ''
    text2 = ''
    flag2 = -1
    text_out = None
    while running:
        background = back2

        screen.fill(WHITE)

        screen.blit(background, (0, 0))
        for k, j in zip(range(5), range(1, 10, 2)):
            section[k].topleft = (len_button // 2, HEIGHT * j // 10 - len_button // 2)
            section[k].size = (len_button, len_button)

        for i in pygame.event.get():
            if i.type == pygame.QUIT:
                running = False
            if i.type == pygame.KEYDOWN and i.key == pygame.K_ESCAPE:
                if menu() == False:
                    running = False
            for j, text_module in enumerate(sections_names):
                if section[j].collidepoint(pygame.mouse.get_pos()):
                    flag2 = 2 * j + 1
                    text2 = text_module[1]
                    if i.type == pygame.MOUSEBUTTONDOWN:
                        text1 = text_module[1]
                        if not module or module != text_module[0]:
                            module = text_module[0]
                            names_rects = module.init()
                        else:
                            module = None
                            names_rects = None
                            text1 = ''
                    break
            else:
                flag2 = -1

            if names_rects is not None and module is not None:
                for name_of_rect, rect in names_rects:
                    if i.type == pygame.MOUSEBUTTONDOWN and rect.collidepoint(pygame.mouse.get_pos()):
                        if run_button is None:
                            run_button = pygame.Rect((800, 150), (200, 50))
                        if delete_button is None:
                            delete_button = pygame.Rect((800, 250), (200, 50))
                        if name_of_rect in ['print_phrase', 'print_var', 'var_to_int', 'var_to_float', 'var_to_str',
                                    'var_to_list', 'var_to_set', 'clear', 'while', 'for_elem_in', 'for_in_range', 'if']:
                            textpr1 = input_text(module.helping_text(name_of_rect, 0))
                            textpr2 = ''
                            textpr3 = ''
                            textpr4 = ''
                        elif name_of_rect in ['var', 'copy', 'reversed', 'len', 'min', 'max', 'add', 'remove',
                                      'append', 'if_contains', 'if_not_contains']:
                            textpr1 = input_text(module.helping_text(name_of_rect, 0))
                            textpr2 = input_text(module.helping_text(name_of_rect, 1))
                            textpr3 = ''
                            textpr4 = ''
                        elif name_of_rect in ['plus', 'minus', 'multiplication', 'div',
                                      'mod', 'replace', 'elem_by_index', 'index', 'split']:
                            textpr1 = input_text(module.helping_text(name_of_rect, 0))
                            textpr2 = input_text(module.helping_text(name_of_rect, 1))
                            textpr3 = input_text(module.helping_text(name_of_rect, 2))
                            textpr4 = ''
                        elif name_of_rect in ['slice_by_index']:
                            textpr1 = input_text(module.helping_text(name_of_rect, 0))
                            input_text(module.helping_text(name_of_rect, 1))
                            input_text(module.helping_text(name_of_rect, 2))
                            input_text(module.helping_text(name_of_rect, 3))
                        else:
                            textpr1 = ''
                            textpr2 = ''
                            textpr3 = ''
                            textpr4 = ''
                        if None in [textpr1, textpr2, textpr3, textpr4]:
                            return
                        program.append((module, name_of_rect, rect.copy(), textpr1, textpr2, textpr3, textpr4))

            if i.type == pygame.MOUSEBUTTONDOWN and delete_button is not None and delete_button.collidepoint(
                    pygame.mouse.get_pos()):
                if len(program) == 1:
                    run_button = None
                    delete_button = None
                    text_out = None
                program.pop(-1)

            if i.type == pygame.MOUSEBUTTONDOWN and run_button is not None and run_button.collidepoint(
                    pygame.mouse.get_pos()):
                with open('C:output.py', 'w') as file:
                    file.write("with open('console.txt', 'w') as file:\n\tfile.write('')\nfile = open('console.txt', 'a')\n")
                with open('output.py', 'a') as file:
                    for p in program:
                        p[0].action(file, p[1], p[3], p[4], p[5])
                    file.write('\nfile.close()')
                with open('output.py', 'r') as file:
                    command = ''.join(file.readlines())
                    exec(command)
                with open('console.txt', 'r') as file:
                    text_out = []
                    for line in file.readlines():
                        text_out.append(font.render(line[:-1], True, BLACK))


        if module:
            # pygame.draw.rect(screen, (210, 210, 210, 128), ((160, 0), (600, HEIGHT)))
            surface = pygame.Surface((570, HEIGHT), pygame.SRCALPHA)
            surface.fill((255, 255, 255))
            surface.set_alpha(60)
            screen.blit(surface, (160, 0))
            for name_of_rect, rect in names_rects:
                module.blit_img(screen, name_of_rect, rect.topleft)

        text_print = font.render(text1, True, BLACK)
        text2_print = font2.render(text2, True, BLACK)
        if flag2 != -1:
            screen.blit(text2_print, (len_button // 2 - flag2 * 3, HEIGHT * flag2 // 10 - len_button // 2 + 80))

        screen.blit(text_print, (len_button * 2 + 10, len_button // 2))

        for i, color in zip(range(len(buttons.keys())), buttons.keys()):
            screen.blit(buttons[color], section[i].topleft)

        text_title = font.render('ПОЛЕ БЛОК-СХЕМЫ', True, BLACK)
        if program:
            screen.blit(text_title, (780, 50))
            text_run = font2.render('Выполнить программу', True, BLACK)
            screen.blit(run_delete_button_image, run_button)
            screen.blit(text_run, (823, 175))
            text_delete = font2.render('Удалить последний блок', True, BLACK)
            screen.blit(run_delete_button_image, delete_button)
            screen.blit(text_delete, (818, 275))


            surface = pygame.Surface((WIDTH - 760, 150), pygame.SRCALPHA)
            surface.fill((255, 255, 255))
            surface.set_alpha(150)
            screen.blit(surface, (760, HEIGHT - 150))
            pygame.draw.line(screen, BLACK, (760, HEIGHT - 150), (760, HEIGHT), 4)
            pygame.draw.line(screen, BLACK, (760, HEIGHT - 150), (WIDTH, HEIGHT - 150), 4)

            for elem in program:
                if program.index(elem) == 0:
                    last_elem = elem
                    elem[2].topleft = (1200, 20)
                else:
                    elem[2].topleft = (last_elem[2].left, last_elem[2].bottom + 10)
                    draw_the_arrow(last_elem[2].centerx, last_elem[2].bottom, 10)
                    last_elem = elem

                elem[0].blit_img(screen, elem[1], elem[2].topleft)

                cords_with_1text_in_program_for_names = {'print_phrase': (elem[2].centerx - 100, elem[2].centery + 25),
                                                         'print_var': (elem[2].centerx + 12, elem[2].centery - 12),
                                                         'var_to_int': (elem[2].centerx + 20, elem[2].centery - 20),
                                                         'var_to_float': (elem[2].centerx + 20, elem[2].centery - 20),
                                                         'var_to_str': (elem[2].centerx + 20, elem[2].centery - 20),
                                                         'var_to_list': (elem[2].centerx + 20, elem[2].centery - 20),
                                                         'var_to_set': (elem[2].centerx + 20, elem[2].centery - 20),
                                                         'clear': (elem[2].centerx + 15, elem[2].centery),
                                                         'while': (elem[2].centerx - 5, elem[2].centery - 22),
                                                         'for_elem_in': (elem[2].centerx - 30, elem[2].centery + 36),
                                                         'for_in_range': (elem[2].centerx + 22, elem[2].centery - 18),
                                                         'if': (elem[2].centerx - 20, elem[2].centery - 20)}
                cords_with_2texts_in_program_for_names = {'var': [(elem[2].centerx + 18, elem[2].centery - 40),
                                                                  (elem[2].centerx - 35, elem[2].centery - 5)],
                                                          'copy': [(elem[2].centerx - 45, elem[2].centery - 42),
                                                                   (elem[2].centerx - 5, elem[2].centery - 5)],
                                                          'reversed': [(elem[2].centerx - 35, elem[2].centery + 20),
                                                                       (elem[2].centerx - 35, elem[2].centery - 5)],
                                                          'len': [(elem[2].centerx - 35, elem[2].centery - 40),
                                                                  (elem[2].centerx, elem[2].centery)],
                                                          'min': [(elem[2].centerx - 38, elem[2].centery - 50),
                                                                  (elem[2].centerx + 60, elem[2].centery + 8)],
                                                          'max': [(elem[2].centerx - 35, elem[2].centery - 45),
                                                                  (elem[2].centerx + 15, elem[2].centery)],
                                                          'add': [(elem[2].centerx + 18, elem[2].centery - 35),
                                                                  (elem[2].centerx + 25, elem[2].centery - 10)],
                                                          'remove': [(elem[2].centerx + 15, elem[2].centery - 23),
                                                                     (elem[2].centerx + 50, elem[2].centery)],
                                                          'append': [(elem[2].centerx + 18, elem[2].centery - 35),
                                                                     (elem[2].centerx + 5, elem[2].centery - 5)],
                                                          'if_contains': [(elem[2].centerx - 66, elem[2].centery - 30),
                                                                          (elem[2].centerx - 13, elem[2].centery - 4)],
                                                          'if_not_contains': [
                                                              (elem[2].centerx - 8, elem[2].centery - 45),
                                                              (elem[2].centerx - 13, elem[2].centery + 8)]}
                cords_with_3texts_in_program_for_names = {'plus': [(elem[2].centerx - 35, elem[2].centery - 35),
                                                                   (elem[2].centerx - 80, elem[2].centery),
                                                                   (elem[2].centerx + 15, elem[2].centery)],
                                                          'minus': [(elem[2].centerx - 35, elem[2].centery - 35),
                                                                    (elem[2].centerx - 80, elem[2].centery),
                                                                    (elem[2].centerx + 15, elem[2].centery)],
                                                          'multiplication':
                                                              [(elem[2].centerx - 35, elem[2].centery - 35),
                                                              (elem[2].centerx - 80, elem[2].centery - 5),
                                                              (elem[2].centerx + 15, elem[2].centery - 5)],
                                                          'div': [(elem[2].centerx - 70, elem[2].centery - 50),
                                                                  (elem[2].centerx - 80, elem[2].centery + 10),
                                                                  (elem[2].centerx + 15, elem[2].centery + 10)],
                                                          'mod': [(elem[2].centerx - 70, elem[2].centery - 55),
                                                                  (elem[2].centerx - 80, elem[2].centery + 10),
                                                                  (elem[2].centerx + 15, elem[2].centery + 10)],
                                                          'replace': [(elem[2].centerx + 12, elem[2].centery - 63),
                                                                      (elem[2].centerx + 25, elem[2].centery - 8),
                                                                      (elem[2].centerx - 10, elem[2].centery + 20)],
                                                          'elem_by_index': [
                                                              (elem[2].centerx - 35, elem[2].centery - 45),
                                                              (elem[2].centerx + 20, elem[2].centery - 22),
                                                              (elem[2].centerx + 45, elem[2].centery + 5)],
                                                          'index': [(elem[2].centerx - 80, elem[2].centery - 48),
                                                                    (elem[2].centerx - 20, elem[2].centery - 18),
                                                                    (elem[2].centerx + 45, elem[2].centery + 8)],
                                                          'split': [(elem[2].centerx, elem[2].centery - 45),
                                                                    (elem[2].centerx + 55, elem[2].centery - 20),
                                                                    (elem[2].centerx + 30, elem[2].centery + 5)]}
                cords_with_4texts_in_program_for_names = {
                    'slice_by_index': [(elem[2].centerx - 80, elem[2].centery - 45),
                                       (elem[2].centerx + 25, elem[2].centery - 45),
                                       (elem[2].centerx + 20, elem[2].centery - 18),
                                       (elem[2].centerx + 23, elem[2].centery + 8)]}

                if elem[6] != '':
                    text1_block = font2.render(elem[3], True, BLACK)
                    text2_block = font2.render(elem[4], True, BLACK)
                    text3_block = font2.render(elem[5], True, BLACK)
                    text4_block = font2.render(elem[6], True, BLACK)
                    screen.blit(text1_block, cords_with_4texts_in_program_for_names[elem[1]][0])
                    screen.blit(text2_block, cords_with_4texts_in_program_for_names[elem[1]][1])
                    screen.blit(text3_block, cords_with_4texts_in_program_for_names[elem[1]][2])
                    screen.blit(text4_block, cords_with_4texts_in_program_for_names[elem[1]][3])
                elif elem[5] != '':
                    text1_block = font2.render(elem[3], True, BLACK)
                    text2_block = font2.render(elem[4], True, BLACK)
                    text3_block = font2.render(elem[5], True, BLACK)
                    screen.blit(text1_block, cords_with_3texts_in_program_for_names[elem[1]][0])
                    screen.blit(text2_block, cords_with_3texts_in_program_for_names[elem[1]][1])
                    screen.blit(text3_block, cords_with_3texts_in_program_for_names[elem[1]][2])
                elif elem[4] != '':
                    text1_block = font2.render(elem[3], True, BLACK)
                    text2_block = font2.render(elem[4], True, BLACK)
                    screen.blit(text1_block, cords_with_2texts_in_program_for_names[elem[1]][0])
                    screen.blit(text2_block, cords_with_2texts_in_program_for_names[elem[1]][1])
                elif elem[3] != '':
                    text_block = font2.render(elem[3], True, BLACK)
                    screen.blit(text_block, cords_with_1text_in_program_for_names[elem[1]])
        k = 0
        if text_out is not None:
            while HEIGHT // 2 > 270 + k * 40 and k < len(text_out):
                screen.blit(text_out[k], (790, HEIGHT // 2 + 275 + k * 40))
                k += 1
        pygame.display.update()
        clock.tick(FPS)


pygame.init()

FPS = 60

screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

WIDTH = screen.get_width()
HEIGHT = screen.get_height()
if WIDTH > 1600 or HEIGHT > 900:
    WIDTH = 1536
    HEIGHT = 864
    screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)

clock = pygame.time.Clock()

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

pygame.font.get_fonts()
font = pygame.font.SysFont('segoeprint', 30)
font_main_title = pygame.font.SysFont('segoeprint', 50)
font2 = pygame.font.SysFont('segoeprint', 20)


#textbox = TextBox(screen, 100, 100, 800, 80, fontSize=50, borderColour=(255, 0, 0), textColour=(0, 200, 0), onSubmit=output, radius=10, borderThickness=5)
text = ''

sections_names = [(basic_section1, 'Основные'), (vars_section2, 'Переменные'),
                  (math_section3, 'Математика'),
                  (methods_and_functions_section4, 'Методы и функции'),
                  (conditions_and_loops_section5, 'Условные операторы и циклы')]


buttons = dict()
for color in ['orange', 'pink', 'white', 'violet', 'blue']:
    with open(f'files/pearls_{color.upper()}_small.bmp') as button_file:
        buttons[color] = pygame.image.load(button_file)


with open('files/фон1.bmp') as file:
    back1 = pygame.image.load(file)
with open('files/фон.bmp') as file:
    back2_2 = pygame.image.load(file)
with open('files/фон2.bmp') as file:
    back2 = pygame.image.load(file)
with open('files/фон_2вар.bmp') as file:
    back3 = pygame.image.load(file)
with open('files/run_convert_button.bmp') as file:
    run_delete_button_image = pygame.image.load(file)

section = []

start_menu()
#main()

pygame.quit()
