import pygame


with open('files/plus.bmp') as file:
    plus_image = pygame.image.load(file)
with open('files/minus.bmp') as file:
    minus_image = pygame.image.load(file)
with open('files/multiplication.bmp') as file:
    multiplication_image = pygame.image.load(file)
with open('files/div.bmp') as file:
    div_image = pygame.image.load(file)
with open('files/mod.bmp') as file:
    mod_image = pygame.image.load(file)
with open('files/max.bmp') as file:
    max_image = pygame.image.load(file)
with open('files/min.bmp') as file:
    min_image = pygame.image.load(file)

name_img = dict(plus=plus_image, minus=minus_image, multiplication=multiplication_image, div=div_image,
                mod=mod_image, max=max_image, min=min_image)


def init():
    # Возвращает список объектов, имеющих координаты для меню
    result_list = []
    for name, i, coords in zip(name_img.keys(), name_img.values(),
                                   [(200, 100), (200, 260), (200, 420), (200, 580), (470, 100), (470, 260), (470, 420), (470, 580)]):
        rect = i.get_rect()
        rect.topleft = coords
        result_list.append((name, rect))
    return result_list


def blit_img(screen, name, rect):
    screen.blit(name_img[name], rect)


def action(file, name, text1='', text2='', text3=''):
    from basic_section1 import flag_tab
    if flag_tab:
        print('    '*flag_tab, end='', file=file)
    if name == 'plus':
        print(f"{text1} = {text2} + {text3}", file=file)
    if name == 'minus':
        print(f"{text1} = {text2} - {text3}", file=file)
    if name == 'multiplication':
        print(f"{text1} = {text2} * {text3}", file=file)
    if name == 'div':
        print(f"{text1} = {text2} // {text3}", file=file)
    if name == 'mod':
        print(f"{text1} = {text2} % {text3}", file=file)
    if name == 'max':
        print(f"{text1} = max({text2})", file=file)
    if name == 'min':
        print(f"{text1} = min({text2})", file=file)


def helping_text(name, i):
    global texts
    return texts[name][i]


texts = {'min': [['Введите имя присваемой переменной:'], ['Введите имя существующего массива:']],
             'max': [['Введите имя присваемой переменной:'], ['Введите имя существующего массива:']],
             'if_contains': [['Введите значение:'], ['Введите значение:']],
             'if_not_contains': [['Введите значение:'], ['Введите значение:']],
             'plus': [['Введите имя присваемой переменной:',
                       'Эту операцию можно использовать для склеивания двух строк или списков в один',
                       'или для добавления элемента в список'],
                      ['Введите первое слагаемое:', 'или имя строки/списка к которому хотите присоединить следующее'],
                      ['Введите второе слагаемое:']],
             'minus': [['Введите имя присваемой переменной:'],
                       ['Введите уменьшаемое:', 'Введите вычитаемое:']],
             'multiplication': [['Введите имя присваемой переменной:'],
                                ['Введите первый множитель'], ['Введите второй множитель:']],
             'div': [['Введите имя присваемой переменной:'], ['Введите делимое:'], ['Введите делитель:']],
             'mod': [['Введите имя присваемой переменной:'], ['Введите делимое:'], ['Введите делитель:']]}