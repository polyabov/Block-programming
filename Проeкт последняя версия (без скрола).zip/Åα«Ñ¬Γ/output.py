with open('console.txt', 'w') as file:
	file.write('')
file = open('console.txt', 'a')
	print('XCVGBH', file=file)

file.close()