import pygame
import pygame_widgets
from pygame_widgets.textbox import TextBox

pygame.init()
def output():
    global text
    text = textbox.getText()

WIDTH = 400
HEIGHT = 400
FPS = 60

WHITE = (255, 255, 255)
RED = (255, 204, 153)
GREEN = (184, 184, 108)
BLUE = (174, 132, 139)
text = ''
rect = (100, 200)
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
clock = pygame.time.Clock()
running = True
while running:
    screen.fill(WHITE)
    events = pygame.event.get()
    textbox = TextBox(screen, rect[0], rect[1], 400, 60, fontSize=50, borderColour=(0, 0, 0), textColour=(0, 0, 200),
                      onSubmit=output, radius=20, borderThickness=4)

    for i in events:
        if i.type == pygame.QUIT:
            running = False
        elif i.type == pygame.KEYDOWN and i.key == pygame.K_RETURN:
            pygame_widgets.update(events)

    pygame_widgets.update(events)
    pygame.display.update()
    clock.tick(FPS)

pygame.quit()
