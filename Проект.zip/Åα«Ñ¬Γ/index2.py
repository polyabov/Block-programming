import pygame
import pygame_widgets
from pygame_widgets.textbox import TextBox
import basic_section1
import vars_section2
import math_section3
import methods_and_functions_section4
import conditions_and_loops_section5

def settings():
    global WIDTH, HEIGHT, screen, clock, FPS, WHITE, BLACK, font, font2, back1, i

    text_title = font.render('НАСТРОЙКИ:', True, BLACK)
    text_set1 = font.render('Настройки1', True, BLACK)
    text_set2 = font.render('Настройки2', True, BLACK)
    button_set1 = pygame.Rect((WIDTH * 0.5 - (WIDTH * 0.2 + 150) // 2, HEIGHT * 0.4),
                                      (WIDTH * 0.2 + 150, HEIGHT * 0.1))
    button_set2 = pygame.Rect((WIDTH * 0.5 - (WIDTH * 0.2 + 150) // 2, HEIGHT * 0.6),
                                  (WIDTH * 0.2 + 150, HEIGHT * 0.1))

    screen.blit(text_title, (WIDTH * 0.5 - 50, HEIGHT * 0.2))

    pygame.draw.rect(screen, WHITE, button_set1)
    pygame.draw.rect(screen, WHITE, button_set2)
    screen.blit(text_set1, button_set1.topleft)
    screen.blit(text_set2, button_set2.topleft)
    if i.type == pygame.KEYDOWN and i.key == pygame.K_ESCAPE:
        return


def polz():
    pass


def menu():
    global WIDTH, HEIGHT, screen, clock, FPS, WHITE, BLACK, font, font2, back1, i

    text_title = font.render('МЕНЮ:', True, BLACK)
    text_settings = font.render('Настройки', True, BLACK)
    text_polz = font.render('Руководство пользователя', True, BLACK)
    button_settings = pygame.Rect((WIDTH * 0.5 - (WIDTH * 0.2 + 150) // 2, HEIGHT * 0.4),
                                   (WIDTH * 0.2 + 150, HEIGHT * 0.1))
    button_polz = pygame.Rect((WIDTH * 0.5 - (WIDTH * 0.2 + 150) // 2, HEIGHT * 0.6),
                                  (WIDTH * 0.2 + 150, HEIGHT * 0.1))

    screen.blit(text_title, (WIDTH * 0.5 - 50, HEIGHT * 0.2))

    pygame.draw.rect(screen, WHITE, button_settings)
    pygame.draw.rect(screen, WHITE, button_polz)
    screen.blit(text_settings, button_settings.topleft)
    screen.blit(text_polz, button_polz.topleft)
    if i.type == pygame.KEYDOWN and i.key == pygame.K_ESCAPE:
        start_menu()
    if button_settings.collidepoint(pygame.mouse.get_pos()):
        if i.type == pygame.MOUSEBUTTONDOWN:
                settings()
    elif button_polz.collidepoint(pygame.mouse.get_pos()):
        if i.type == pygame.MOUSEBUTTONDOWN:
                polz()



def start_menu():
    global WIDTH, HEIGHT, screen, clock, FPS, WHITE, BLACK,  font, font2, back1, i, running

    text_title = font.render('БЛОЧНОЕ ПРОГРАММИРОВАНИЕ', True, BLACK)
    text_start = font.render('Начать', True, BLACK)
    text_menu = font.render('Меню', True, BLACK)
    button_start = pygame.Rect((WIDTH * 0.5 - (WIDTH * 0.2 + 150)//2, HEIGHT * 0.4), (WIDTH * 0.2 + 150, HEIGHT * 0.1))
    button_menu = pygame.Rect((WIDTH*0.5 - (WIDTH * 0.2 + 150)//2, HEIGHT*0.6), (WIDTH * 0.2 + 150, HEIGHT * 0.1))

    screen.blit(text_title, (WIDTH * 0.5 - 285, HEIGHT * 0.2))

    pygame.draw.rect(screen, WHITE, button_start)
    pygame.draw.rect(screen, WHITE, button_menu)
    screen.blit(text_start, button_start.topleft)
    screen.blit(text_menu, button_menu.topleft)
    if i.type == pygame.QUIT or (i.type == pygame.KEYDOWN and i.key == pygame.K_ESCAPE):
        running = False
    if i.type == pygame.MOUSEBUTTONDOWN:
        if button_start.collidepoint(pygame.mouse.get_pos()):
            main()
        elif button_menu.collidepoint(pygame.mouse.get_pos()):
            menu()
        pygame.display.update()
        clock.tick(FPS)


def output():
    global text
    text = textbox.getText()


def input_text():
    global WIDTH, HEIGHT, screen, clock, FPS, WHITE, BLACK, font, font2, textbox

    running = True
    while running:
        events = pygame.event.get()
        for i in events:
            if i.type == pygame.QUIT:
                return
            elif i.type == pygame.KEYDOWN and i.key == pygame.K_RETURN:
                pygame_widgets.update(events)
                return

        pygame_widgets.update(events)

        pygame.display.update()
        clock.tick(FPS)


def main():
    global WIDTH, HEIGHT, screen, clock, FPS, WHITE, BLACK, font, font2, text
    program = []
    module = None
    names_rects = None

    running = True

    len_button = buttons['pink'].get_width()
    for k in range(1, 10, 2):
        section.append(pygame.Rect((WIDTH // 18 - len_button // 2, HEIGHT * k // 14 - len_button // 2),
                                   (len_button * 2, len_button * 2)))

    background = back2
    text1 = ''
    text2 = ''
    flag2 = -1

    while running:

        WIDTH = screen.get_width()
        HEIGHT = screen.get_height()
        screen.fill(WHITE)

        screen.blit(background, (0, 0))
        for k, j in zip(range(5), range(1, 10, 2)):
            section[k].topleft = (len_button // 2, HEIGHT * j // 10 - len_button // 2)
            section[k].size = (len_button, len_button)

        for i in pygame.event.get():

            if i.type == pygame.QUIT:
                running = False
            if i.type == pygame.KEYDOWN and i.key == pygame.K_ESCAPE:
                return menu()
            for j, text_module in enumerate(sections_names):
                if section[j].collidepoint(pygame.mouse.get_pos()):
                    flag2 = 2 * j + 1
                    text2 = text_module[1]

                    if i.type == pygame.MOUSEBUTTONDOWN:
                        text1 = text_module[1]
                        if not module or module != text_module[0]:
                            module = text_module[0]
                            names_rects = module.init()
                        else:
                            module = None
                            names_rects = None
                            text1 = ''
                    break
            else:
                flag2 = -1

            if names_rects is not None and module is not None:
                for name, rect in names_rects:
                    if i.type == pygame.MOUSEBUTTONDOWN and rect.collidepoint(pygame.mouse.get_pos()):
                        print('It was put down')
                        if name in ['print_phrase']:
                            input_text()
                            program.append((module, name, rect.copy(), text))
                        else:
                            program.append((module, name, rect.copy()))


        if not module:  # == if module is None
            pass
        else:
            # pygame.draw.rect(screen, (210, 210, 210, 128), ((160, 0), (600, HEIGHT)))
            surface = pygame.Surface((600, HEIGHT), pygame.SRCALPHA)
            surface.fill((255, 255, 255))
            surface.set_alpha(60)
            screen.blit(surface, (160, 0))
            for name, rect in names_rects:
                ########
                pygame.draw.rect(screen, (255, 0, 0), rect)
                ########
                module.blit_img(screen, name, rect.topleft)

        text_print = font.render(text1, True, WHITE)
        text2_print = font2.render(text2, True, BLACK)
        if flag2 != -1:
            screen.blit(text2_print, (len_button // 2 - flag2 * 3, HEIGHT * flag2 // 10 - len_button // 2 + 80))

        screen.blit(text_print, (len_button * 2 + 10, len_button // 2))

        for i, color in zip(range(len(buttons.keys())), buttons.keys()):
            screen.blit(buttons[color], section[i].topleft)
        if program:
            for elem in program:
                if program.index(elem) == 0:
                    last_elem = elem
                    elem[2].topleft = (1100, 50)
                else:
                    elem[2].topleft = (last_elem[2].left, last_elem[2].bottom + 10)
                    last_elem = elem

                elem[0].blit_img(screen, elem[1], elem[2].topleft)

        pygame.display.update()
        clock.tick(FPS)


pygame.init()

FPS = 60

WIDTH = 600
HEIGHT = 700

screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
clock = pygame.time.Clock()

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

pygame.font.get_fonts()
font = pygame.font.SysFont('segoeprint', 30)
font2 = pygame.font.SysFont('segoeprint', 20)


textbox = TextBox(screen, 100, 100, 800, 80, fontSize=50, borderColour=(255, 0, 0), textColour=(0, 200, 0), onSubmit=output, radius=10, borderThickness=5)
text = ''

sections_names = [(basic_section1, 'Основные'), (vars_section2, 'Переменные'),
                  (math_section3, 'Математика'),
                  (methods_and_functions_section4, 'Методы и функции'),
                  (conditions_and_loops_section5, 'Условные операторы и циклы')]


buttons = dict()
for color in ['orange', 'pink', 'white', 'violet', 'blue']:
    with open(f'files/pearls_{color.upper()}_small.bmp') as button_file:
        buttons[color] = pygame.image.load(button_file)


with open('files/фон1.bmp') as file:
    back1 = pygame.image.load(file)
with open('files/фон2.bmp') as file:
    back2 = pygame.image.load(file)
with open('files/фон_2вар.bmp') as file:
    back3 = pygame.image.load(file)

section = []

start_menu()
#main()

pygame.quit()
