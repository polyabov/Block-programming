import pygame


with open('files/plus.bmp') as file:
    plus_image = pygame.image.load(file)
with open('files/minus.bmp') as file:
    minus_image = pygame.image.load(file)
with open('files/multiplication.bmp') as file:
    multiplication_image = pygame.image.load(file)
with open('files/div.bmp') as file:
    div_image = pygame.image.load(file)
with open('files/mod.bmp') as file:
    mod_image = pygame.image.load(file)
with open('files/len.bmp') as file:
    len_image = pygame.image.load(file)
with open('files/max.bmp') as file:
    max_image = pygame.image.load(file)
with open('files/min.bmp') as file:
    min_image = pygame.image.load(file)

name_img = dict(plus=plus_image, minus=minus_image, multiplication=multiplication_image, len=len_image, div=div_image,
                mod=mod_image, max=max_image, min=min_image)


def init():
    # Возвращает список объектов, имеющих координаты для меню
    result_list = []
    for name, i, coords in zip(name_img.keys(), name_img.values(),
                                   [(200, 100), (200, 260), (200, 420), (200, 580), (470, 100), (470, 260), (470, 420), (470, 580)]):
        rect = i.get_rect()
        rect.topleft = coords
        result_list.append((name, rect))
    return result_list


def blit_img(screen, name, rect):
    screen.blit(name_img[name], rect)

from basic_section1 import flag_tab
def action(file, name, text1='', text2='', text3=''):
    global flag_tab
    if flag_tab:
        print(f"\t", end='', file=file)
    if name == 'plus':
        print(f"{text1} = {text2} + {text3}", file=file)
    if name == 'minus':
        print(f"{text1} = {text2} - {text3}", file=file)
    if name == 'multiplication':
        print(f"{text1} = {text2} * {text3}", file=file)
    if name == 'len':
        print(f"{text1} = len({text2})", file=file)
    if name == 'div':
        print(f"{text1} = {text2} // {text3}", file=file)
    if name == 'mod':
        print(f"{text1} = {text2} % {text3}", file=file)
    if name == 'max':
        print(f"{text1} = max({text2})", file=file)
    if name == 'min':
        print(f"{text1} = min({text2})", file=file)