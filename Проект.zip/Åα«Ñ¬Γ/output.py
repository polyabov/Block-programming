a = '5'
a = int(float(a))
if a==5:
	print(a)
	