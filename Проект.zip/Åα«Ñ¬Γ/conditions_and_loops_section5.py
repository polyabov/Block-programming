import pygame


with open('files/if.bmp') as file:
    if_image = pygame.image.load(file)
with open('files/else.bmp') as file:
    else_image = pygame.image.load(file)
with open('files/while.bmp') as file:
    while_image = pygame.image.load(file)
with open('files/for_elem_in.bmp') as file:
    for_elem_in_image = pygame.image.load(file)
with open('files/for_in_range.bmp') as file:
    for_in_range_image = pygame.image.load(file)
with open('files/if_contains.bmp') as file:
    if_contains_image = pygame.image.load(file)
with open('files/if_not_contains.bmp') as file:
    if_not_contains_image = pygame.image.load(file)


name_img = {'while': while_image,
            'for_elem_in': for_elem_in_image,
            'for_in_range': for_in_range_image,
            'if': if_image,
            'else': else_image,
            'if_contains': if_contains_image,
            'if_not_contains': if_not_contains_image}

def init():
    # Возвращает список объектов, имеющих координаты для меню
    result_list = []
    for name, i, coords in zip(name_img.keys(), name_img.values(),
                                   [(200, 100), (200, 300), (200, 500), (470, 100), (470, 280), (470, 460), (470, 640)]):
        rect = i.get_rect()
        rect.topleft = coords
        result_list.append((name, rect))
    return result_list


def blit_img(screen, name, rect, text1='', text2='', text3=''):
    screen.blit(name_img[name], rect)

from basic_section1 import flag_tab
def action(file, name, text1='', text2='', text3=''):
    global flag_tab
    if flag_tab:
        print(f"\t", end='', file=file)
    if name == 'while':
        print(f"while {text1}:", file=file)
    elif name == 'for_elem_in':
        print(f"for elem in {text1}:", file=file)
    elif name == 'for_in_range':
        print(f"for i in range({text1})", file=file)
    elif name == 'if':
        print(f"if {text1}:", file=file)
    elif name == 'else':
        print('else:', file=file)
    elif name == 'if_contains':
        print(f"if {text1} in {text2}:", file=file)
    elif name == 'if_not_contains':
        print(f"if {text1} not in {text2}:", file=file)